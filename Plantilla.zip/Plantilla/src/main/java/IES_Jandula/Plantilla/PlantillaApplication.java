package IES_Jandula.Plantilla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlantillaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlantillaApplication.class, args);
	}

}
