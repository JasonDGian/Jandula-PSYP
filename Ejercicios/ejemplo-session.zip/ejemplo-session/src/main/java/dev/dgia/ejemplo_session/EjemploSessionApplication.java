package dev.dgia.ejemplo_session;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploSessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploSessionApplication.class, args);
	}

}
