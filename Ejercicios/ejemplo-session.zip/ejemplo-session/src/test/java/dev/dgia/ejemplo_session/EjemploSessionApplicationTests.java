package dev.dgia.ejemplo_session;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
